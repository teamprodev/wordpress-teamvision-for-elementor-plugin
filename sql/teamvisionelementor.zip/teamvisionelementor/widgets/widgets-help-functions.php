<?php
/*
Addon: TEAMVISION Functions 
*/

add_action( 'after_setup_theme', 'teamvision_setup' );
if(!function_exists('teamvision_setup')) {
	function teamvision_setup() {
		add_image_size( 'teamvision-large', 1000, 800, true );	
	}
}

if(!function_exists('teamvision_animate_class')) {
	function teamvision_animate_class($addon_animate,$effect,$delay) {
		if($addon_animate == 'on') : 
			wp_enqueue_script( 'appear' );			
			wp_enqueue_script( 'animate' );		
			$animate_class = ' animate-in" data-anim-type="'.$effect.'" data-anim-delay="'.$delay.'"'; 
		else :
			$animate_class = '"';
		endif;		
		return $animate_class;
	}
}